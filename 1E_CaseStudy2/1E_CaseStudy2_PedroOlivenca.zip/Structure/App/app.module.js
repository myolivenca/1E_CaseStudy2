﻿angular.module('App', ['easypiechart']);
